package hw3;

public class PrimeCalculator {
    public void primesTo(int n) { // required method to calculate and print
        if (n < 2) {
            System.out.println("Error: Input must be a number greater than or equal to 2.");
            return;
        }
        
        ArrayQueue<Integer> numbers = new ArrayQueue<>(n - 1);
        ArrayQueue<Integer> primes = new ArrayQueue<>(n - 1);
        
        // I have to initialize numbers queue with numbers from 2 to n
        for (int i = 2; i <= n; i++) {
            numbers.enqueue(i);
        }
        
        while (!numbers.isEmpty()) {  // while there are numbers left in the numbers queue
            int p = numbers.dequeue();
            primes.enqueue(p);
            
            int size = numbers.size();  // each number left in numbers, dequeue
            for (int i = 0; i < size; i++) {
                int num = numbers.dequeue();
                if (num % p != 0) {
                    numbers.enqueue(num); // enqueue it back if its not divisible by p
                }
            }
        }
        
        System.out.print("Printing primes up to " + n + ":\n");
        while (!primes.isEmpty()) {
            System.out.print(primes.dequeue());
            if (!primes.isEmpty()) {
                System.out.print(", ");
            } else {
                System.out.println(".");
            }
        }
    }
    // main method to test
    public static void main(String[] args) {
        new PrimeCalculator().primesTo(20);
        new PrimeCalculator().primesTo(2);
        new PrimeCalculator().primesTo(0);
    }
}
